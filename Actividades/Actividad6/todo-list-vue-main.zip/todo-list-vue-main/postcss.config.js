export default {
    plugins: {
      '@tailwindcss/postcss7-compat': {},
      autoprefixer: {},
    },
  }
  